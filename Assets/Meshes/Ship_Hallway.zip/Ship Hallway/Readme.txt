Filetype: Lightwave Object File
Size: 170 KB
Points: 8063
Polygons: 4370
Bones: None
Textured: Yes
UV Texture: Included
Layered Object: Yes
Subdivided: No

This Lightwave object that has been provided is created for all your 3D 
needs.  Hope you enjoy this model.
 
Created by the Funky Chicken.
